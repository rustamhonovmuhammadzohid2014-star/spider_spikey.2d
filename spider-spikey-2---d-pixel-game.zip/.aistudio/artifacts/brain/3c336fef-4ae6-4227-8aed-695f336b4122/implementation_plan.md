# Spider Spikey — Creator VIP, High-Stakes Economy & Real Friends Plan

A major progression, social, and economy expansion for Spider Spikey that introduces high-stakes Market and Case pricing (10,000+ base skins/cases and 100,000+ ZAI Limited exclusives), 3×–5× harder Daily/Weekly/Seasonal missions, a server-verified **Creator VIP (`Admin`)** account mode with `∞` coins and a live Side Admin Panel, and a real **Add Friend & Gifting** system synced through an integrated Express backend without Firebase.

## User Review & Critical Decisions

> [!IMPORTANT]
> All four architectural and gameplay decisions confirmed during clarification are locked into this plan. No Firebase SDK, authentication, or cloud database is used anywhere; multi-account synchronization runs cleanly through the application's own Node/Express backend.

- **Friends & Admin Sync Architecture**: **App server sync without Firebase for real friends**. Player accounts register and synchronize friend requests, inbox transfers, and Admin gifts through the app's Express backend while retaining fast local browser saves and JSON backups.
- **Accepted Friend Gifting Scope**: **Coins plus owned spider and web skins**. Once two players accept each other's friend request, they can send Spikey Coins as well as owned Spider Skins and Web Designs from their inventory.
- **Creator Account Onboarding (`ZAIlimited`)**: **Instant VIP login as `Admin` with all items unlocked**. Entering the valid Creator key logs directly into the VIP `Admin` profile with `∞` coins, VIP crown/status, every skin/web/avatar/frame unlocked, and the Side Admin Panel enabled.
- **Mission Difficulty Scaling**: **Hard 3× to 5× targets across all missions** (Daily, Weekly, and Seasonal), turning every mission tier into a meaningful long-term skill challenge.
- **Recommended Defaults**:
  - **Shareable Account IDs**: Short, readable human-friendly IDs (e.g., `SPK-XXXXXX`) revealed on demand via the **Account ID** button with one-tap copy.
  - **Resale Anti-Exploit Ratio**: Skin and Web Design sell prices remain below 45% of purchase cost across the new 10,000–150,000+ tier so Case openings never generate infinite coin loops.
  - **ZAI Date-Gating & 38-Language Parity**: Existing ZAI release-date locks remain strictly enforced for regular players, and every new label (`Try again`, `Creator Account`, `Add Friend`, `Account ID`, `Admin Panel`) is translated across all 38 supported languages.

---

## 1. Overview & Core Concept

- **What It Does**: Elevates Spider Spikey's progression into a high-value collectible economy paired with real friend-to-friend social gifting and a privileged Creator administration mode—while preserving every existing platforming world, `E` Spider House / `Q` Web Swing mechanic, video tutorial academy, and ZAI calendar rule.
- **Target Audience**: Competitive desktop and mobile Spider Spikey players across 38 languages who want deeper long-term progression, friend trading/gifting via shareable IDs, and an optional VIP Creator control suite for managing community rewards.
- **Key Value**: Transforms coins and rare cosmetics into true milestones, introduces genuine cross-account gifting without Firebase, and equips the game creator with instant VIP testing and friend-reward tools.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **High-Stakes Market, Cases & 3×–5× Missions**:
   - Regular players see Common skins and web designs starting at **10,000 Spikey Coins**, scaling smoothly through Uncommon (**18,000–22,000**), Rare (**32,000–40,000**), Epic (**55,000–70,000**), Legendary (**85,000–96,000**), and **ZAI Limited** exclusives priced at **100,000–155,000+** Spikey Coins.
   - Cases mirror the new economy tier starting at **10,000 Coins** for a Common Case up to **140,000+** for Mythic and ZAI Limited Cases, keeping all probability disclosures and ZAI release-date locks intact.
   - Daily, Weekly, and Seasonal mission targets scale **3×–5×** higher with balanced high-tier coin rewards.
2. **Account Creation & Creator VIP Entry**:
   - On the **Account Creation** screen (and profile switcher), players see the normal nickname/avatar builder alongside a prominent **Creator Account** button.
   - Clicking **Creator Account** opens a dedicated passcode modal.
   - **Wrong Key**: Displays a clear localized **"Try again"** error message (in the active language across all 38 languages) and offers an immediate button to switch/open a **Normal Account** instead.
   - **Valid Key (`ZAIlimited`)**: Verified on the backend server; immediately logs into the **VIP `Admin`** account with all skins, webs, avatars, and frames unlocked, an **`∞` (Infinity)** coin indicator across every wallet header/market/HUD view, and non-depleting VIP purchasing/gifting.
3. **Side Admin Panel (Creator VIP Only)**:
   - While signed in as **Admin**, a collapsible/docked **Side Admin Panel** appears on the edge of the menu workspace without obscuring gameplay.
   - Displays all registered/synced player accounts (`nickname`, Account ID, and whether they are currently friends with `Admin`).
   - Enforces the friendship rule: Admin can send any custom amount of **Spikey Coins**, **Spider Skins**, or **Web Designs** to accounts that are accepted friends of `Admin` (with quick friend-request / acceptance controls right inside the panel and Friends view).
4. **Add Friend ("Do'st qo'shish") & Gift Transfers**:
   - Main Menu features a clear **Add Friend** button opening the Friends & Gifting workspace.
   - Clicking **Account ID** reveals the player's shareable ID with one-tap copy feedback.
   - **ID Search & Privacy Gate**: Entering any player's ID shows their nickname and avatar to send a friend request. **Special Admin Privacy Rule**: if a player searches the Creator `Admin` account's ID, the interface displays **only the name `Admin`** with zero stats, wallet, skin list, or extra profile details.
   - **Requests & Gifting**: Incoming requests show **Accept** and **Decline** actions. Accepted friends appear in the **Friends List**, where clicking **Send Gift** lets a player transfer **Spikey Coins**, an **owned Spider Skin**, or an **owned Web Design** (deducted atomically from regular players and delivered to the friend's synced inbox).

### Visual Identity & Theme
- **Aesthetic Direction**: Authentic 16-bit dark-winter pixel platformer paired with crisp frosted slate arcade panels—maintaining zero static rounded pill capsules (metadata uses clean inline text separated by `·`), crisp pixel borders, single-elevation cards, and zero thick left accent stripes (`border-l-4`).
- **Color Palette & Budget (60-30-10)**:
  - *60% Dominant Canvas*: Midnight winter slate (`#070b14` / `#0b1628`).
  - *30% Structural Surfaces*: Frosted dark slate panels (`#0f172a` / `#132038`) with crisp pixel borders (`border-slate-700/80`).
  - *10% Focused Accents*: Frost cyan (`#38bdf8`) for primary actions and Add Friend controls, VIP royal amber (`#fbbf24`) for `∞` VIP indicators and ZAI gold items, and crimson (`#ef4444`) strictly for invalid-key warnings and ZAI neon alerts.
- **Typography & Hierarchy**:
  - *Display*: `Silkscreen` for pixel headings, VIP/Admin titles, and arcade buttons.
  - *Body*: `Plus Jakarta Sans` for crisp, accessible 38-language labels, friend search inputs, and mission descriptions.
  - *Telemetry & Currency*: `JetBrains Mono` with `tabular-nums` for 10,000+ / 100,000+ coin counters, `∞` VIP wallet readouts, and mission targets.
- **Interactive Feedback & Mobile Readiness**: Touch targets $\ge 44\text{px}$ on mobile and $\ge 40\text{px}$ on desktop, compositor-only (`transform`, `opacity`) modal/panel transitions, non-blocking toast notifications for incoming gifts and friend requests, and zero browser `alert`/`open` popups.

---

## 3. Key Product Decisions & Trade-Offs

- **Express App-Server Sync vs. Browser-Only Storage**:
  - *Chosen Approach*: Run an integrated Express backend alongside the Vite frontend to maintain a lightweight persistent store of registered accounts, unique shareable IDs, friend requests, accepted friendships, and pending gift/coin transfers—while preserving fast client-side saves and JSON backup export/import.
  - *Why*: Browser `localStorage` alone cannot let two real users share IDs, accept friend requests, or exchange coins/skins across separate sessions or devices. Using the app's own server achieves real multi-account sync with zero Firebase dependencies.
  - *Alternatives Considered*: Local-only simulated friends (rejected because real ID lookup and real Admin-to-player transfers were requested).
- **Friend-Gated Transfers & Atomic Gift Inbox**:
  - *Chosen Approach*: Require mutual friendship acceptance before either regular players or Admin can transfer coins, spider skins, or web designs, and deliver transfers through a server-backed gift inbox claimed cleanly on sync/poll.
  - *Why*: Prevents unsolicited transfers, honors the explicit rule that recipients must be friends first, and prevents duplicate claims or race conditions when both accounts are active.
- **Server-Side Creator Key Verification & Masked Admin Lookup**:
  - *Chosen Approach*: Verify the Creator passcode (`ZAIlimited`) solely on the backend rather than shipping secret checks in browser JavaScript, issue an in-memory Bearer session token for VIP `Admin` actions, and return a strictly redacted `{ id, nickname: "Admin" }` projection when anyone searches the Admin ID.
  - *Why*: Keeps privileged VIP authentication secure while guaranteeing that searching the Creator's ID reveals nothing beyond the name `Admin`.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

```
┌────────────────────────────────────────────────────────────────────────────┐
│                      CLIENT APPLICATION (React + Canvas)                   │
│  [Account Setup & Creator Modal] · [Winter Main Menu + Add Friend CTA]     │
│  [High-Stakes Market & Cases]    · [3x–5x Missions] · [VIP ∞ Wallet HUD]   │
│  [Friends & Gifting Modal]       · [Side Admin Panel (Creator VIP Only)]   │
└───────────────────────────────┬────────────────────────────────────────────┘
                                │ HTTPS /api/* (In-Memory Bearer Session)
                                ▼
┌────────────────────────────────────────────────────────────────────────────┐
│                   EXPRESS SYNC & AUTH SERVER (No Firebase)                 │
│  • Profile Sync & Unique Shareable ID Registry (SPK-XXXXXX)                │
│  • Creator VIP Verification & All-Unlocked Entitlements                    │
│  • ID Lookup with Redacted Admin-Only Privacy Projection                   │
│  • Friend Requests (Send / Accept / Decline) & Friendship Gate             │
│  • Atomic Coin, Spider Skin & Web Design Gift Queue + Claim Sync           │
└───────────────────────────────┬────────────────────────────────────────────┘
                                │ Atomic File Persistence + Local Cache
                                ▼
┌────────────────────────────────────────────────────────────────────────────┐
│                         PERSISTENT STORAGE LAYER                           │
│  • Server Account/Friend/Gift Store · Client localStorage + IndexedDB      │
└────────────────────────────────────────────────────────────────────────────┘
```

### Data Model & State
- **Synced Player Directory Record**: Stores unique `accountId` (short shareable code), `nickname`, `avatarId`, `isCreator` flag, active friend IDs, incoming/outgoing friend requests, and pending gift envelopes (`coins`, `skinIds`, `webIds`, sender info).
- **Creator VIP Entitlements**: When authenticated as Creator (`isCreator: true`), wallet displays `∞` across every UI surface, purchase validators short-circuit cost checks without deducting coins, and every skin, web design, avatar, and profile frame resolves as unlocked.
- **Economy Rebalance Tables**:
  - **Skins & Web Designs**: Re-tiered prices starting at `10,000` (Common) up to `100,000–155,000` (ZAI Limited), keeping `sellPrice < 45%` of price.
  - **Cases**: Re-tiered prices starting at `10,000` (Common) up to `140,000` (Mythic) and `110,000–145,000` (ZAI Limited cases), retaining exact drop odds and ZAI calendar checks.
  - **Missions**: All Daily, Weekly, and Seasonal targets scaled `3×–5×` with matched high-tier coin rewards.

### Interactive Component & State Mapping
- **Account Creation & Creator Login Flow**: Submitting a nickname registers/syncs the local profile with the backend and obtains a shareable Account ID + session token; clicking **Creator Account** submits the passcode to the backend—returning either an instant VIP `Admin` session or a localized `"Try again"` error with a one-click path back to normal account creation.
- **Friends & ID Discovery Flow**: Clicking **Add Friend** opens the Friends modal; clicking **Account ID** reveals/copies the user's `SPK-...` ID; searching an ID queries the lookup endpoint (returning redacted `{ nickname: "Admin" }` for Creator IDs or public `{ nickname, avatarId }` for regular users); sending/accepting requests updates both parties' friend lists; sending a gift validates ownership and balance on the server, debits non-VIP senders atomically, and queues the reward into the recipient's inbox for automatic claim.
- **Side Admin Panel Flow**: Rendered only for authenticated Creator sessions; lists all synced accounts with friend status (`Friend` / `Request Pending` / `Not Friend`), includes a quick friend-request trigger if not yet connected, and lets Admin dispatch custom coin amounts, spider skins, and web designs to accepted friends.

### Verified Security Safeguards
- **Server-Only Creator Passcode Verification**: The Creator passcode is verified exclusively on the Express backend (never embedded in client-side source code), issuing a session Bearer token stored strictly in React/JS memory rather than browser storage.
- **Strict Ownership, Balance & Friendship Enforcement**: Every friend mutation, Admin dispatch, and gift transfer validates the caller's session token, confirms mutual friendship on the server, validates integer coin bounds and item ownership, and commits inventory/balance updates atomically.
- **Admin Privacy Redaction & Safe Rendering**: Searching the Creator ID returns only `{ id, nickname: "Admin" }` with zero financial or inventory fields, and all user-supplied nicknames, IDs, and messages render strictly through safe React text bindings with schema validation.
